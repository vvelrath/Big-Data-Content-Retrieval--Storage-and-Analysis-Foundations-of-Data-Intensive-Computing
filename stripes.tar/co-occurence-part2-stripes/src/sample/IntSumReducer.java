package sample;

import java.io.IOException;
import java.util.Map.Entry;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Reducer;

public class IntSumReducer 
extends Reducer<Text,MapWritable,Text,DoubleWritable> {
	private DoubleWritable result = null;
	
	protected void setup(Context context) throws IOException, InterruptedException 
	{
		result = new DoubleWritable();
	}
	
	public void reduce(Text key, Iterable<MapWritable> values, Context context) throws IOException, InterruptedException {
		MapWritable sum = new MapWritable();
		
		double frequency = 0;
		double marginal = 0;
		for (MapWritable val : values) {
			sum = addToMap(sum,val);
		}
		
		String word1 = key.toString();
		
		for (Writable map_values : sum.values())
		{
			IntWritable map_value_wr = (IntWritable) map_values;
			int map_value_int = map_value_wr.get();
			marginal += map_value_int;
		}	
		
		for (Entry<Writable, Writable> map_entry : sum.entrySet()) 
		{
			Text word2_text = (Text) map_entry.getKey();
			String word2 = word2_text.toString();
			
			String word_pair = word1.concat(",").concat(word2);
			key.set(word_pair);
			
			IntWritable value2_wr = (IntWritable) map_entry.getValue();
			double value = value2_wr.get();
			
			frequency = value/marginal;
			result.set(frequency);
			context.write(key, result);
		}
	}
	
	public MapWritable addToMap(MapWritable map1, MapWritable map2)
	{
		MapWritable map3 = new MapWritable();
		map3.putAll(map1);
		
		for (Entry<Writable, Writable> map_entry : map2.entrySet()) 
		{
		    Text key_text = (Text) map_entry.getKey();
		    
		    IntWritable value_wr = (IntWritable) map_entry.getValue();
		    int value_int = value_wr.get();
		    
		    if(map3.containsKey(key_text))
		    {
		    	IntWritable value2 = (IntWritable) map3.get(key_text);
			    int value2_int = value2.get();
			    
			    int total_value = value_int + value2_int;
			    IntWritable total_value_wr = new IntWritable(total_value);

		    	map3.put(key_text, total_value_wr);
		    }	
		    else
		    {
		    	IntWritable value_int_wr = new IntWritable(value_int);
		    	map3.put(key_text, value_int_wr);
		    }	
		    	
		}
		
		return map3;
		
	}
}
