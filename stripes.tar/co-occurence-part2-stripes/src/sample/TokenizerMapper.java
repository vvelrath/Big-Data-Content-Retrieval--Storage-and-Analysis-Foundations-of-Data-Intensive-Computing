package sample;

import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class TokenizerMapper extends Mapper<Object, Text, Text, MapWritable>{

	private Text word = new Text();
	Pattern p1 = Pattern.compile("^[\\(!'\"\\?!\\.]+");
	Pattern p2 = Pattern.compile("[\"'\\*\\?!\\.\\/\\)\\):]+$");

	public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
	
		String delims = " ,;";
		StringTokenizer itr = new StringTokenizer(value.toString(),delims);
		
		ArrayList<String> tokens = new ArrayList<String>();
		while(itr.hasMoreTokens())
		{
			String newtoken = cleanToken(itr.nextToken());
			
			if((newtoken.startsWith("@")||newtoken.startsWith("#")) && newtoken.length()>1)
				tokens.add(newtoken);
			
			if(newtoken.length()>0 && !newtoken.startsWith("@") && !newtoken.startsWith("#") && newtoken.matches("[a-z]+"))
				tokens.add(newtoken);
		}	
		
		
		for(int i=0;i<tokens.size()-1;i++)
		{
			String word1 = tokens.get(i);
			MapWritable map = new MapWritable();
			
			for(int j=i+1;j<tokens.size();j++)
			{
				Text word2 = new Text(tokens.get(j));
				if(map.containsKey(word2))
				{
					IntWritable wr = (IntWritable)map.get(word2);
					int co_int = wr.get()+1;
					IntWritable int_wr = new IntWritable(co_int); 
					map.put(word2, int_wr);
				}
				else
				{
					IntWritable one = new IntWritable(1);
					map.put(word2, one);
				}	
			}
			word.set(word1);
			context.write(word, map);
		}	
		
	}
	
	public String cleanToken(String token)
	{
		String newtoken = null;
		
		Matcher m1 = p1.matcher(token);
		
		if(m1.find()) 
			newtoken=m1.replaceAll("");
		else
			newtoken=token;
		
		Matcher m2 = p2.matcher(newtoken);
		
		if(m2.find()) 
			newtoken=m2.replaceAll("");
		
		return newtoken;
	}
}