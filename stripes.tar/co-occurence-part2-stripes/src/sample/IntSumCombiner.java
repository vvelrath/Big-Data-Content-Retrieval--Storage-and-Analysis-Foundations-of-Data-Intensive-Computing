package sample;

import java.io.IOException;
import java.util.Map.Entry;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Reducer;

public class IntSumCombiner 
extends Reducer<Text,MapWritable,Text,MapWritable> {
	
	
	public void reduce(Text key, Iterable<MapWritable> values, Context context) throws IOException, InterruptedException {
		MapWritable sum = new MapWritable();
		for (MapWritable val : values) {
			sum = addToMap(sum,val);
		}
		
		context.write(key, sum);
		
	}
	
	public MapWritable addToMap(MapWritable map1, MapWritable map2)
	{
		MapWritable map3 = new MapWritable();
		map3.putAll(map1);
		
		for (Entry<Writable, Writable> map_entry : map2.entrySet()) 
		{
		    Text key_text = (Text) map_entry.getKey();
		    
		    IntWritable value_wr = (IntWritable) map_entry.getValue();
		    int value_int = value_wr.get();
		    
		    if(map3.containsKey(key_text))
		    {
		    	IntWritable value2 = (IntWritable) map3.get(key_text);
			    int value2_int = value2.get();
			    
			    int total_value = value_int + value2_int;
			    IntWritable total_value_wr = new IntWritable(total_value);

		    	map3.put(key_text, total_value_wr);
		    }	
		    else
		    {
		    	IntWritable value_int_wr = new IntWritable(value_int);
		    	map3.put(key_text, value_int_wr);
		    }	
		    	
		}
		
		return map3;
		
	}
}