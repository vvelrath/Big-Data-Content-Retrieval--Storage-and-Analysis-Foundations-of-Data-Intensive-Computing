package sample;

import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;


	 
public class MyPartitioner extends Partitioner<Text, MapWritable> {
	@Override
	public int getPartition(Text key, MapWritable value, int numPartitions) {
		
		String word = key.toString();;
		
		int partition = Math.abs(word.hashCode()%numPartitions);
		
		return partition;
	}
 
}
	
	


