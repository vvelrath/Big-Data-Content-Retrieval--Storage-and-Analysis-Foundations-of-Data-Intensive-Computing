package sample;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;


	 
public class MyPartitioner extends Partitioner<Text, IntWritable> {
	@Override
	public int getPartition(Text key, IntWritable value, int numPartitions) {
		
		String wordPair = key.toString();
		String word1 = wordPair.split(",")[0];
		
		int partition = Math.abs(word1.hashCode()%numPartitions);
		
		return partition;
	}
 
}
	
	


