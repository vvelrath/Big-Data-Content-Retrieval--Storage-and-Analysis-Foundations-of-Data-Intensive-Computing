package sample;

import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class TokenizerMapper extends Mapper<Object, Text, Text, IntWritable>{

	private final static IntWritable one = new IntWritable(1);
	private Text word = new Text();
	Pattern p1 = Pattern.compile("^[\\(!'\"\\?!\\.]+");
	Pattern p2 = Pattern.compile("[\"'\\*\\?!\\.\\/\\)\\):]+$");

	public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
	
		String delims = " ,;";
		StringTokenizer itr = new StringTokenizer(value.toString(),delims);
		
		ArrayList<String> tokens = new ArrayList<String>();
		while(itr.hasMoreTokens())
		{
			String newtoken = cleanToken(itr.nextToken());
			
			if((newtoken.startsWith("@")||newtoken.startsWith("#")) && newtoken.length()>1)
				tokens.add(newtoken);
			
			if(newtoken.length()>0 && !newtoken.startsWith("@") && !newtoken.startsWith("#") && newtoken.matches("[a-z]+"))
				tokens.add(newtoken);
		}	
		
		
		for(int i=0;i<tokens.size();i++)
		{
			String word1 = tokens.get(i);
			String word1_marginal = word1.concat(",");
			for(int j=i+1;j<tokens.size();j++)
			{
				String word2 = tokens.get(j);
				String wordpair = word1.concat(",").concat(word2);
				
				word.set(word1_marginal);
				context.write(word, one);
				
				word.set(wordpair);
				context.write(word, one);
			}	
		}	
		
	}
	
	public String cleanToken(String token)
	{
		String newtoken = null;
		
		Matcher m1 = p1.matcher(token);
		
		if(m1.find()) 
			newtoken=m1.replaceAll("");
		else
			newtoken=token;
		
		Matcher m2 = p2.matcher(newtoken);
		
		if(m2.find()) 
			newtoken=m2.replaceAll("");
		
		return newtoken;
	}
}