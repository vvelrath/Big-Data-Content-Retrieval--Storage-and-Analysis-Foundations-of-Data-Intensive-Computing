package sample;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Counters;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WordCount {

	private static final transient Logger LOG = LoggerFactory.getLogger(WordCount.class);

	static enum Centroids
	{
		FIRST,
		SECOND,
		THIRD
	}
	
	public static long prev_first = 0;
	public static long prev_second = 0;
	public static long prev_third = 0;
	
	
	public static void main(String[] args) throws Exception {

		
		boolean zero_iterations = true;
		boolean convergence = false;
		long curr_first = 0;
		long curr_second = 0;
		long curr_third = 0;


		while(convergence == false)
		{	
			Configuration conf = new Configuration();		

			LOG.info("HDFS Root Path: {}", conf.get("fs.defaultFS"));
			LOG.info("MR Framework: {}", conf.get("mapreduce.framework.name"));
			
			/* Set the Input/Output Paths on HDFS */
			String inputPath = "/input";
			String outputPath = "/output";
			
			/* FileOutputFormat wants to create the output directory itself.
			 * If it exists, delete it:
			 */
			deleteFolder(conf,outputPath);
			
						
			//Setting up counters for k-means
			
			if(zero_iterations==false)
			{	
				prev_first = curr_first;
				prev_second = curr_second;
				prev_third = curr_third;
			}
			else
			{
				prev_first = 50;
				prev_second = 500;
				prev_third = 1000;
				zero_iterations = false;
			}	
		
			
			conf.setLong("PREV_FIRST", prev_first);
			conf.setLong("PREV_SECOND", prev_second);
			conf.setLong("PREV_THIRD", prev_third);

			Job job = Job.getInstance(conf);
			
			job.setJarByClass(WordCount.class);
			job.setMapperClass(TokenizerMapper.class);
		
			job.setReducerClass(IntSumReducer.class);
			job.setOutputKeyClass(Text.class);
			job.setOutputValueClass(LongWritable.class);
			FileInputFormat.addInputPath(job, new Path(inputPath));
			FileOutputFormat.setOutputPath(job, new Path(outputPath));
			
			job.waitForCompletion(true);
			
			if(job.isSuccessful())
			{
				Counters counter = job.getCounters();
				curr_first = counter.findCounter(WordCount.Centroids.FIRST).getValue();
				curr_second = counter.findCounter(WordCount.Centroids.SECOND).getValue();
				curr_third = counter.findCounter(WordCount.Centroids.THIRD).getValue();
			
				long diff_first = Math.abs(prev_first-curr_first);
				long diff_second = Math.abs(prev_second-curr_second);
				long diff_third = Math.abs(prev_third-curr_third);
				
				if(diff_first<1 && diff_second<1 && diff_third<1)
				{	
					convergence = true;
					System.exit(0);
				}
			}	
		}	
	}
	
	/**
	 * Delete a folder on the HDFS. This is an example of how to interact
	 * with the HDFS using the Java API. You can also interact with it
	 * on the command line, using: hdfs dfs -rm -r /path/to/delete
	 * 
	 * @param conf a Hadoop Configuration object
	 * @param folderPath folder to delete
	 * @throws IOException
	 */
	private static void deleteFolder(Configuration conf, String folderPath ) throws IOException {
		FileSystem fs = FileSystem.get(conf);
		Path path = new Path(folderPath);
		if(fs.exists(path)) {
			fs.delete(path,true);
		}
	}
}