package sample;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class TokenizerMapper extends Mapper<Object, Text, Text, LongWritable>{

	private long first = 0;
	private long second = 0;
	private long third = 0;

	public void setup(Context context)
	{
		Configuration conf = context.getConfiguration();
		first = Long.parseLong(conf.get("PREV_FIRST"));
		second = Long.parseLong(conf.get("PREV_SECOND"));
		third = Long.parseLong(conf.get("PREV_THIRD"));
	}
	
	public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
		
		String flag = null;
		StringTokenizer itr = new StringTokenizer(value.toString());
		
		String follower_str = "";
		while(itr.hasMoreTokens())
			follower_str = itr.nextToken();
		
		
		long follower = Integer.parseInt(follower_str);
		
		long diff_first = Math.abs(first - follower);
		long diff_second = Math.abs(second - follower);
		long diff_third = Math.abs(third - follower);
		
		long cluster = 0;
		long inter_min = 0;
		
		if(diff_first<diff_second)
			inter_min = diff_first;
		else
			inter_min = diff_second;
		
		if(inter_min>diff_third)
			inter_min = diff_third;
		
		if(inter_min == diff_first)
		{
			cluster = first;
			flag = "F";
		}	
		else if(inter_min == diff_second)
		{
			cluster = second;
			flag = "S";
		}	
		else
		{
			cluster = third;
			flag = "T";
		}	
			
		String cluster_str = cluster+" "+flag;
		Text cluster_word = new Text();
		cluster_word.set(cluster_str);
		
		
		LongWritable follower_wr = new LongWritable(follower);
				
		context.write(cluster_word, follower_wr);
		
	}
}
