package sample;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import sample.WordCount.Centroids;

public class IntSumReducer 
extends Reducer<Text,LongWritable,Text,LongWritable> {

	public void reduce(Text key, Iterable<LongWritable> values, Context context) throws IOException, InterruptedException {
		long sum = 0;
		long noofpoints = 0;
		for (LongWritable val : values) {
			sum += val.get();
			noofpoints +=1;
		}
	
		StringTokenizer itr = new StringTokenizer(key.toString());
		String old_cluster = itr.nextToken();
		String flag = itr.nextToken();
		
		long new_cluster = sum/noofpoints;
	
		if(flag.equals("F"))
			context.getCounter(Centroids.FIRST).setValue(new_cluster);
		else if(flag.equals("S"))
			context.getCounter(Centroids.SECOND).setValue(new_cluster);
		else
			context.getCounter(Centroids.THIRD).setValue(new_cluster);
	}
}
