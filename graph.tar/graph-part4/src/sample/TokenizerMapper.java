package sample;

import java.io.IOException;
import java.util.StringTokenizer;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class TokenizerMapper extends Mapper<Object, Text, Text, Text>{

	public void setup(Context context)
	{
		context.getCounter(WordCount.Converged.FLAG).setValue(1);
	}
	
	public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
		
		
		StringTokenizer itr = new StringTokenizer(value.toString());
		
		String node = itr.nextToken();
		Text node_txt = new Text(node);
		
		String weight = itr.nextToken();
		int new_weight = Integer.parseInt(weight)+1;
		String new_weight_str = String.valueOf(new_weight);
		Text new_weight_wr = new Text(new_weight_str);
		
		String path = itr.nextToken();
		
		String original_weight = weight.concat(" ").concat(path).concat(" ").concat("*");
		Text original_weight_txt = new Text(original_weight);
		
		context.write(node_txt, original_weight_txt);
		
		StringTokenizer itr_path = new StringTokenizer(path,":");
		
		while(itr_path.hasMoreTokens())
		{
			node = itr_path.nextToken();
			node_txt.set(node);
			context.write(node_txt, new_weight_wr);
		}
	}
}
