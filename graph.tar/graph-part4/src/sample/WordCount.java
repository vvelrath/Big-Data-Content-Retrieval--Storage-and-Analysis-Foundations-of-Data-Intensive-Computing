package sample;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Counters;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WordCount {

	private static final transient Logger LOG = LoggerFactory.getLogger(WordCount.class);
	
	static enum Converged
	{
		FLAG;
	}
	
	public static void main(String[] args) throws Exception {

		boolean convergence = false;
		String inputPath = "";
		String outputPath = "";
		int iterations = 0;
		
		while(convergence == false)
		{	
			Configuration conf = new Configuration();		

			LOG.info("HDFS Root Path: {}", conf.get("fs.defaultFS"));
			LOG.info("MR Framework: {}", conf.get("mapreduce.framework.name"));
			
			/* Set the Input/Output Paths on HDFS */ 
			
			if(iterations==0)
				inputPath = "/input";
			else
			{	
				deleteFolder(conf,outputPath.concat("/_SUCCESS"));
				inputPath=outputPath;
			}
			iterations++;
			outputPath = "/output".concat(String.valueOf(iterations));
			
			/* FileOutputFormat wants to create the output directory itself.
			 * If it exists, delete it:
			 */
			deleteFolder(conf,outputPath);

			Job job = Job.getInstance(conf);
			
			job.setJarByClass(WordCount.class);
			job.setMapperClass(TokenizerMapper.class);
		
			job.setReducerClass(IntSumReducer.class);
			job.setOutputKeyClass(Text.class);
			job.setOutputValueClass(Text.class);
			FileInputFormat.addInputPath(job, new Path(inputPath));
			FileOutputFormat.setOutputPath(job, new Path(outputPath));
			
			job.waitForCompletion(true);
			
			if(job.isSuccessful())
			{
				Counters counter = job.getCounters();
				long converged_flag = counter.findCounter(Converged.FLAG).getValue();
					
				if(converged_flag==1)
				{	
					convergence = true;
					renameFolder(conf, outputPath);
					System.exit(0);
				}
			}	
		}	
	}
	
	/**
	 * Delete a folder on the HDFS. This is an example of how to interact
	 * with the HDFS using the Java API. You can also interact with it
	 * on the command line, using: hdfs dfs -rm -r /path/to/delete
	 * 
	 * @param conf a Hadoop Configuration object
	 * @param folderPath folder to delete
	 * @throws IOException
	 */
	private static void deleteFolder(Configuration conf, String folderPath ) throws IOException {
		FileSystem fs = FileSystem.get(conf);
		Path path = new Path(folderPath);
		if(fs.exists(path)) {
			fs.delete(path,true);
		}
	}
	
	private static void renameFolder(Configuration conf, String folderPath ) throws IOException {
		FileSystem fs = FileSystem.get(conf);
		Path old_path = new Path(folderPath);
		Path path = new Path("/output");
		if(fs.exists(path)) {
			fs.delete(path,true);
		}
		fs.rename(old_path, path);
	}

}