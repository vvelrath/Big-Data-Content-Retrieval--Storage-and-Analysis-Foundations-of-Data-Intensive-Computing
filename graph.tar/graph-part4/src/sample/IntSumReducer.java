package sample;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class IntSumReducer 
extends Reducer<Text,Text,Text,Text> {

	public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {

		int minimum = 0;
		int weight_int = 0;
		String path = "";
		int curr_weight = 0;
		for (Text val : values) {
			String value = val.toString();
			if(value.endsWith("*"))
			{
				StringTokenizer itr = new StringTokenizer(value);
				String weight = itr.nextToken();
				weight_int = Integer.parseInt(weight);
				curr_weight = weight_int;
				path = itr.nextToken();
			}
			else
			{
				weight_int = Integer.parseInt(value);
			}
			
			if(weight_int<minimum)
				minimum = weight_int;
			
			if(minimum==0)
				minimum = weight_int;
		}
		
		if(curr_weight!=minimum&&!key.toString().equals("1"))
		{
			context.getCounter(WordCount.Converged.FLAG).setValue(2);
		}
		
		String new_weight_adlist = "";
		
		if(key.toString().equals("1"))
			new_weight_adlist = String.valueOf(0).concat(" ").concat(path);
		else
			new_weight_adlist = String.valueOf(minimum).concat(" ").concat(path);
		
		Text new_weight_adlist_wr = new Text(new_weight_adlist);
		
		context.write(key, new_weight_adlist_wr);
	
	}
}
