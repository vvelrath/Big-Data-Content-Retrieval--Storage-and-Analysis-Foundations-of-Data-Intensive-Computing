package sample;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;


	 
public class MyPartitioner extends Partitioner<Text, IntWritable> {
	@Override
	public int getPartition(Text key, IntWritable value, int numPartitions) {
		
		String tempCollector = key.toString();
 
		if( tempCollector.startsWith("#") )
			return 1;
		else if( tempCollector.startsWith("@") )
			return 2;
		else
			return 0;
	}
 
}
	
	


