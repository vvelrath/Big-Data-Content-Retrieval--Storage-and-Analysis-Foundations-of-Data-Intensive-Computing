package sample;

import java.io.IOException;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class TokenizerMapper extends Mapper<Object, Text, Text, IntWritable>{

	private final static IntWritable one = new IntWritable(1);
	private Text word = new Text();
	Pattern p1 = Pattern.compile("^[\\(!'\"\\?!\\.]+");
	Pattern p2 = Pattern.compile("[\"'\\*\\?!\\.\\/\\)\\):]+$");
	String newtoken = null;

	public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
	
		String delims = " ,;";
		StringTokenizer itr = new StringTokenizer(value.toString(),delims);
		
		while (itr.hasMoreTokens()) {
			String token = itr.nextToken();
			
			Matcher m1 = p1.matcher(token);
			
			if(m1.find()) 
				newtoken=m1.replaceAll("");
			else
				newtoken=token;
			
			Matcher m2 = p2.matcher(newtoken);
			
			if(m2.find()) 
				newtoken=m2.replaceAll("");
			
			if(newtoken.length()>0)
			{	
				word.set(newtoken);
				if(newtoken.startsWith("@")||newtoken.startsWith("#"))
					context.write(word, one);
				else
				{
					if(newtoken.matches("[a-z]+"))
						context.write(word, one);
				}	
			}
			newtoken=null;
		}
	}
}