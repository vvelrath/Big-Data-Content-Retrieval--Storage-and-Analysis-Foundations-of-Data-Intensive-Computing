package sample;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;


	 
public class SorterPartitioner extends Partitioner<LongWritable, Text> {
	@Override
	public int getPartition(LongWritable key, Text value, int numPartitions) {
		
		String tempCollector = value.toString();
 
		if( tempCollector.startsWith("#") )
			return 1;
		else if( tempCollector.startsWith("@") )
			return 2;
		else
			return 0;
	}
 
}
	
	


